package models;

/**
 * Created by IntelliJ IDEA.
 * User: canelmas
 * Date: Dec 5, 2011
 * Time: 12:15:28 PM
 * To change this template use File | Settings | File Templates.
 */
public enum ServiceProgressStatus {

    RESOLVED, READY_TO_BE_RATED, NOT_RESOLVED;
    
}
