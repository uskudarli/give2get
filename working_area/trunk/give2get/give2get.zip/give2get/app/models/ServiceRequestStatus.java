package models;

/**
 * Created by IntelliJ IDEA.
 * User: canelmas
 * Date: Dec 4, 2011
 * Time: 2:03:17 PM
 * To change this template use File | Settings | File Templates.
 */
public enum ServiceRequestStatus {

    PENDING, ACCEPTED, DECLINED, RESOLVED;
}
