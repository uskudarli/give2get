package com.boun.give2get.exceptions;

/**
 * Created by IntelliJ IDEA.
 * User: canelmas
 * Date: Nov 8, 2011
 * Time: 4:39:17 PM
 * To change this template use File | Settings | File Templates.
 */
public class MailException extends Exception{

    public MailException(Exception e) {
        super(e);

    }
}
