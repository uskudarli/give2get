package com.boun.give2get.core;

/**
 * Created by IntelliJ IDEA.
 * User: canelmas
 * Date: Nov 8, 2011
 * Time: 4:49:44 PM
 * To change this template use File | Settings | File Templates.
 */
public final class Configuration {

    public static String getFS() {
        return System.getProperty("file.separator");
    }

}
